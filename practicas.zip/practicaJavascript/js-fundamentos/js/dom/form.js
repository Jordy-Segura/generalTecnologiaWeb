const form = document.querySelector("form");
const message = document.getElementById("message");

form.addEventListener("submit", (event)=> {
  event.preventDefault();

  const numUno = document.getElementById("num-uno").value.trim();
  const numDos = document.getElementById("num-dos").value.trim();

  if (numUno === "" || numDos === "") {
    message.textContent = "Please complete all fields.";
    return;
  }

  message.textContent = `Suma = ${parseFloat(numUno) + parseFloat(numDos)}`;
});