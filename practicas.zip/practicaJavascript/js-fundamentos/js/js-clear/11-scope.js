const productName = "laptop";
const price = 899;
const brand = "techCode";

<<<<<<< HEAD:js/11-scope.js
const getProductInfo = () => {
=======
const getProductInfo=()=> {
>>>>>>> d462591aabf303592c57c6c9c1eaba1c691aa879:js/js-clear/11-scope.js
    const productName = "smartphone";
    const price = 499;
    return `${productName} costs ${price} and is of brand ${brand}`;
}

console.log(getProductInfo());

//console.log(`${productName} costs ${price} and is of brand ${brand}`);