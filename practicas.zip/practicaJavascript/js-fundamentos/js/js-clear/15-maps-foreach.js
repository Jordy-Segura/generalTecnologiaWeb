// Methods that iterate over an array.
// Methods that DO NOT modify the original array (Immutability).

// map()

/*const numbers = [1, 2, 3, 4, 5]
const squaredNumbers = numbers.map(num => num * num)

console.log(numbers)
console.log(squaredNumbers)

// forEach()

const colors = ['red', 'pink', 'blue']
const iteratedColors = colors.forEach(color => console.log(color))

console.log(colors)
console.log(iteratedColors)
*/
// Exercise: Fahrenheit to Celsius conversion
/*
const temperaturesInFahrenheit = [32, 68, 95, 104, 212]

<<<<<<< HEAD:js/15-maps-foreach.js
const temperaturesInCelsius = temperaturesInFahrenheit.map(fahrenheit => fahrenheit + 1)
=======
const temperaturesInCelsius = temperaturesInFahrenheit.map(pepito =>  (pepito + 1))
>>>>>>> d462591aabf303592c57c6c9c1eaba1c691aa879:js/js-clear/15-maps-foreach.js

console.log('Temperatures In Fahrenheit: ', temperaturesInFahrenheit)
console.log('Temperatures In Celsius: ', temperaturesInCelsius)
*/
// Exercise: Sum of Elements in an Array

const newNumbers = [1, 2, 3, 4, 5]
let sum = 0
newNumbers.forEach(number => {
  par(number)
})
function par (number) {
  sum += number
}
console.log('Array of Numbers: ', newNumbers)
console.log('Sum of Numbers: ', sum)