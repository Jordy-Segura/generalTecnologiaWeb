/*
Operadores de comparación
*/
/*
== 
=== 
!= 
!== 
>
< 
>= 
<= */

const a = 10; 
const b = 20; 
const c = "10"

console.log(a == c); 